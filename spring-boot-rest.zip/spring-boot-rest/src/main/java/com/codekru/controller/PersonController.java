package com.codekru.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.codekru.model.Person;

@RestController
public class PersonController {

    @RequestMapping("/")
    public List<Person> getPersonList() {
        List<Person> persons = new ArrayList<>();
        persons.add(new Person("Mohan", "tyagi", 20));
        persons.add(new Person("Raman", "Chhabra", 28));
        return persons;
    }

}
